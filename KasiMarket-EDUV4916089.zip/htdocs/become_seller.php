<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];


$check = mysqli_query($conn, "SELECT * FROM seller_requests WHERE user_id='$user_id'");
$request = mysqli_fetch_assoc($check);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (!$request) {

        $sql = "INSERT INTO seller_requests (user_id, status)
                VALUES ('$user_id', 'pending')";

        if (mysqli_query($conn, $sql)) {
            $success = "Your seller application has been submitted and is awaiting admin approval.";
        } else {
            $error = "Error submitting application.";
        }

    } else {
        $error = "You have already submitted a seller application.";
    }
}
if(isset($_GET['message'])){
    echo "<div class='alert alert-info'>
            You must be approved as a seller before listing products.
          </div>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Become a Seller</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="container mt-5">

    <div class="card mx-auto shadow" style="max-width: 600px;">

        <div class="card-body">

            <h2 class="mb-3">Become a Seller</h2>

            <p>
                To sell products on our marketplace, you must first apply
                for seller status. Your application will be reviewed by an
                administrator before approval.
            </p>

            <?php if(isset($success)){ ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php } ?>

            <?php if(isset($error)){ ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php } ?>

            <?php if($request){ ?>

                <?php if($request['status'] == 'pending'){ ?>

                    <div class="alert alert-warning">
                        Your seller application is currently under review.
                    </div>

                <?php } elseif($request['status'] == 'approved'){ ?>

                    <div class="alert alert-success">
                        Your seller application has been approved.
                    </div>

                    <a href="add_product.php" class="btn btn-success">
                        Start Selling
                    </a>

                <?php } elseif($request['status'] == 'rejected'){ ?>

                    <div class="alert alert-danger">
                        Your seller application was rejected.
                    </div>

                <?php } ?>

            <?php } else { ?>

                <form method="POST">

                    <button type="submit" class="btn btn-success">
                        Apply to Become a Seller
                    </button>

                </form>

            <?php } ?>

            <hr>

            <a href="dashboard.php" class="btn btn-secondary">
                Back to Dashboard
            </a>

        </div>

    </div>

</div>

</body>
</html>
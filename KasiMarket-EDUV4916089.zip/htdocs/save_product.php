<?php
session_start();
include "config.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$title = $_POST['title'];
$description = $_POST['description'];
$price = $_POST['price'];
$image = $_POST['image'];

$sql = "INSERT INTO products (user_id, title, description, price, image)
VALUES ('$user_id', '$title', '$description', '$price', '$image')";

if(mysqli_query($conn, $sql)){
    header("Location: marketplace.php");
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
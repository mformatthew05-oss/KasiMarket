<?php
session_start();
include "config.php";
include "includes/header.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("No product ID provided");
}

$id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM products 
        WHERE product_id = $id 
        AND user_id = '$user_id'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    die("Product not found or you do not have permission to edit this product");
}

$product = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<h2>Edit Product</h2>

<form method="POST" action="update_product.php" enctype="multipart/form-data">

    <input type="hidden" name="id" value="<?php echo $product['product_id']; ?>">

    <div class="mb-3">
        <label>Title</label>
        <input type="text" name="title" class="form-control"
               value="<?php echo htmlspecialchars($product['title']); ?>" required>
    </div>

    <div class="mb-3">
        <label>Description</label>
        <textarea name="description" class="form-control" required><?php echo htmlspecialchars($product['description']); ?></textarea>
    </div>

    <div class="mb-3">
        <label>Price</label>
        <input type="number" name="price" class="form-control"
               value="<?php echo $product['price']; ?>" required>
    </div>
    <div class="mb-3">
        <label>Current Image</label><br>
        <img src="<?php echo $product['image']; ?>" width="120">
    </div>

    <div class="mb-3">
        <label>Change Image (optional)</label>
        <input type="file" name="image" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary">
        Update
    </button>

</form>

</body>
</html>
<?php
session_start();
include "includes/header.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasi Market - User Manual</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: url("assets/images/logo/background.png") no-repeat center center fixed;
            background-size: cover;
        }
        .manual-card{
            background: rgba(255,255,255,0.95);
            border-radius:15px;
            padding:30px;
            margin-top:30px;
            margin-bottom:40px;
            box-shadow:0 0 20px rgba(0,0,0,0.2);
        }
        h2{
            color:#198754;
            font-weight:bold;
        }
        h4{
            color:#0d6efd;
            margin-top:25px;
        }
        .logo{
            max-width:180px;
            display:block;
            margin:0 auto 20px auto;
        }
        .back-btn{
            margin-top:30px;
        }
        ul li{
            margin-bottom:8px;
        }
        .toc a{
            text-decoration:none;
        }
        .toc li{
            margin-bottom:6px;
        }
    </style>
</head>

<body>
<div class="container">

    <div class="manual-card">

        <img src="assets/images/logo/Kasi Market logo 1.png"
             class="logo"
             alt="Kasi Market Logo">

        <h2 class="text-center">Kasi Market User Manual</h2>

        <p class="text-center">
            Welcome to <strong>Kasi Market</strong>, a community marketplace where users can buy and sell products safely and easily.
            This guide will help you get started.
        </p>

        <hr>
        <h4>Contents</h4>
        <ol class="toc">
            <li><a href="#register">Creating an Account</a></li>
            <li><a href="#login">Logging In</a></li>
            <li><a href="#browse">Browsing Products</a></li>
            <li><a href="#buy">Buying Products</a></li>
            <li><a href="#seller">Becoming a Seller</a></li>
            <li><a href="#addproduct">Adding Products</a></li>
            <li><a href="#myproducts">Managing Your Products</a></li>
            <li><a href="#profile">Managing Your Profile</a></li>
            <li><a href="#logout">Logging Out</a></li>
            <li><a href="#admin">Administrator Features</a></li>
            <li><a href="#faq">Frequently Asked Questions</a></li>
            <li><a href="#tips">Helpful Tips</a></li>
        </ol>

        <hr>
        <section id="register">
            <h4>1. Creating an Account</h4>
            <p>To start using Kasi Market, you need to register an account.</p>
            <ol>
                <li>Click <strong>Register</strong>.</li>
                <li>Enter your Username.</li>
                <li>Enter your Email Address.</li>
                <li>Create a secure Password.</li>
                <li>Click <strong>Register</strong>.</li>
            </ol>
            <p>You can now log into the platform.</p>
        </section>

        <section id="login">
            <h4>2. Logging In</h4>
            <ol>
                <li>Open the Login page.</li>
                <li>Enter your Email.</li>
                <li>Enter your Password.</li>
                <li>Click <strong>Login</strong>.</li>
            </ol>
            <p>If your login details are incorrect, the system will display an error message.</p>
        </section>

        <section id="browse">
            <h4>3. Browsing Products</h4>
            <p>After logging in, you can browse products available on the marketplace.</p>

            <ul>
                <li>View product images.</li>
                <li>Read descriptions.</li>
                <li>Compare prices.</li>
                <li>See seller information.</li>
            </ul>
        </section>

        <section id="buy">
            <h4>4. Buying Products</h4>
            <ol>
                <li>Select a product.</li>
                <li>Read the product details carefully.</li>
                <li>Review the price.</li>
                <li>Follow the purchasing process provided by the platform.</li>
                <li>Complete your purchase.</li>
            </ol>
        </section>

        <section id="seller">
            <h4>5. Becoming a Seller</h4>
            <p>Registered users can apply to become sellers.</p>

            <ol>
                <li>Go to <strong>Become a Seller</strong>.</li>
                <li>Submit your seller request.</li>
                <li>Wait for administrator approval.</li>
                <li>Once approved, seller features become available.</li>
            </ol>
        </section>

        <section id="addproduct">
            <h4>6. Adding Products</h4>
            <ol>
                <li>Open <strong>Add Product</strong>.</li>
                <li>Enter the Product Name.</li>
                <li>Add a Description.</li>
                <li>Enter the Price.</li>
                <li>Upload a Product Image.</li>
                <li>Click <strong>Add Product</strong>.</li>
            </ol>
        </section>

        <section id="myproducts">
            <h4>7. Managing Your Products</h4>
            <p>Approved sellers can manage all their products from the <strong>My Products</strong> page.</p>

            <ul>
                <li>View your products.</li>
                <li>Edit product details.</li>
                <li>Update prices.</li>
                <li>Delete products.</li>
            </ul>
        </section>

        <section id="profile">
            <h4>8. Managing Your Profile</h4>
            <p>You can update your account information from your dashboard.</p>
            <ul>
                <li>View your account details.</li>
                <li>Edit your profile information.</li>
                <li>Keep your information up to date.</li>
            </ul>
        </section>

        <section id="logout">
            <h4>9. Logging Out</h4>
            <ol>
                <li>Click the <strong>Logout</strong> button.</li>
                <li>Your session will end securely.</li>
            </ol>
        </section>

        <section id="admin">
            <h4>10. Administrator Features</h4>

            <p>Administrators help manage the platform.</p>
            <ul>
                <li>Approve seller requests.</li>
                <li>Reject seller requests.</li>
                <li>Manage products.</li>
                <li>Manage users.</li>
                <li>Monitor marketplace activity.</li>
            </ul>
        </section>

        <section id="faq">
            <h4>Frequently Asked Questions</h4>

            <p><strong>I can't log in.</strong></p>
            <p>Check your email and password, then try again.</p>

            <p><strong>I can't sell products.</strong></p>
            <p>Your seller request may still be waiting for administrator approval.</p>

            <p><strong>My product isn't showing.</strong></p>
            <p>Ensure your product was added successfully and contains all required information.</p>
        </section>

        <section id="tips">
            <h4>Helpful Tips</h4>
            <ul>
                <li>Use clear product names.</li>
                <li>Upload high-quality product images.</li>
                <li>Write honest descriptions.</li>
                <li>Keep prices updated.</li>
                <li>Check your My Products page regularly.</li>
                <li>Log out when using a shared computer.</li>
            </ul>
        </section>

        <hr>
        <h4>Need Help?</h4>
        <p>
            If you experience any problems while using Kasi Market,
            please contact the platform administrator for assistance.
        </p>
        <div class="text-center back-btn">
            <a href="index.php" class="btn btn-success btn-lg">
                ← Back to Home
            </a>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
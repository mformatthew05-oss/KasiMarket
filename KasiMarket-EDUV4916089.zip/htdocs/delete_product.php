<?php
include "config.php";

if (!isset($_GET['id'])) {
    die("No product ID provided");
}

$id = intval($_GET['id']);

$sql = "DELETE FROM products WHERE product_id = $id";

if (mysqli_query($conn, $sql)) {
    header("Location: seller_product.php?deleted=1");
    exit();
} else {
    echo "Error deleting product";
}
?>
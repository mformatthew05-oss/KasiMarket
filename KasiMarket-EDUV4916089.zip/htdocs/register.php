<?php
include "includes/header.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
</head>
<body>

<div class="container mt-5">
    <div class="card p-4 mx-auto" style="max-width: 500px;">

        <h2 class="text-center mb-4">Register</h2>

        <form action="register_process.php" method="POST" onsubmit="return validateForm()">

            <input type="text"
                   name="username"
                   class="form-control mb-3"
                   placeholder="Username"
                   required>

            <input type="text"
                   name="full_name"
                   class="form-control mb-3"
                   placeholder="Full Name"
                   required>

            <input type="email"
                   name="email"
                   class="form-control mb-3"
                   placeholder="Email"
                   required>

            <input type="password"
                   name="password"
                   class="form-control mb-3"
                   placeholder="Password"
                   required>

            <input type="password"
                   name="confirm_password"
                   class="form-control mb-3"
                   placeholder="Confirm Password"
                   required>

            <button type="submit" class="btn btn-success w-100">
                Register
            </button>

        </form>

        <p class="text-center mt-3">
            Already have an account?
            <a href="login.php">Login Here</a>
        </p>

    </div>
</div>
<form action="register_process.php" method="POST" onsubmit="return validateForm()">

<script>
function validateForm() {
    let password = document.querySelector('input[name="password"]').value;
    let confirmPassword = document.querySelector('input[name="confirm_password"]').value;

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    if (password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
    }

    return true;
}
</script>
</body>
</html>
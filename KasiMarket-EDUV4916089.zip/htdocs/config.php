<?php

$conn = mysqli_connect("sql300.infinityfree.com", "if0_42316349", "osgcCBDGZ9I", "if0_42316349_kasimarket");

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}
define("BASE_URL", "/C2C_PLATFORM_EDUV4916089/");
?>

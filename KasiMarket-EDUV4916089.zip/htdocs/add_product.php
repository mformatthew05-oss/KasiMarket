<?php
session_start();
include "config.php";
include "includes/header.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO products (title, description, price, image, user_id)
            VALUES ('$title', '$description', '$price', '$image', '$user_id')";


if (!$conn) {
    die("DB connection failed");
}
$result = mysqli_query($conn, $sql);
if (!$result) {
    die("SQL Error: " . mysqli_error($conn));
}
header("Location: /c2c_platform_eduv4916089/seller_product.php?success=1");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add your product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label class="form-label">Product Title</label>
        <input type="text" class="form-control"
               name="title" required>
    </div>

        <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea class="form-control"
                  name="description"
                  rows="4"
                  required></textarea>
        </div>

<div class="mb-3">
    <label class="form-label">Price</label>
    <div class="input-group">
        <span class="input-group-text">R</span>
        <input type="number"
               class="form-control"
               name="price"
               placeholder="0.00"
               step="0.01"
               min="0"
               required>
    </div>

<div class="mb-3">
    <label class="form-label">Product Image</label>
    <input type="file"
           class="form-control"
           name="image"
           accept="image/*"
           required>
</div><br><br>

<div class="d-grid">
    <button type="submit" class="btn btn-success btn-lg">
        Add Product
    </button>
</div>
</form>

<style>
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    appearance: textfield;
}
</style>
<footer class="text-center text-white py-3" style="background:#212529; margin:300px;">
    <small>
        © <?php echo date("Y"); ?> KasiMarket | All rights reserved.
    </small>
</footer>
</body>
</html>

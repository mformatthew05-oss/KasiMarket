<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Card Payment</title>
</head>
<body>

<h2>Card Payment</h2>

<form action="process_payment.php" method="POST">

    <input type="text" name="card_name" placeholder="Card Holder Name" required><br><br>

    <input type="text" name="card_number" placeholder="Card Number" maxlength="16" required><br><br>

    <input type="text" name="expiry" placeholder="Expiry Date (MM/YY)" required><br><br>

    <input type="text" name="cvv" placeholder="CVV" maxlength="3" required><br><br>

    <button type="submit">Pay Now</button>

</form>

</body>
</html>
<?php
session_start();
include "config.php";

$user_id = $_SESSION['user_id'];
$title = $_POST['title'];
$description = $_POST['description'];
$price = $_POST['price'];


$image_name = $_FILES['image']['name'];
$image_tmp = $_FILES['image']['tmp_name'];

$folder = "uploads/" . $image_name;

move_uploaded_file($image_tmp, $folder);

$sql = "INSERT INTO products (user_id, title, description, price, image)
        VALUES ('$user_id', '$title', '$description', '$price', '$folder')";

if(mysqli_query($conn, $sql)){
    echo "Product added successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
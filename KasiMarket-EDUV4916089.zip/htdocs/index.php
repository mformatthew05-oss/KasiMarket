<?php include "includes/header.php"; ?>

<div class="container mt-5 text-center">

    <h1 class="display-4">
        Welcome to KasiMarket
    </h1>

    <p class="lead">
        Buy and sell products safely within your community.
    </p>

    <a href="marketplace.php" class="btn btn-success btn-lg">
        Browse Products
    </a>
<a href="user_manual.php" class="btn btn-success btn-lg">
    User Manual
</a>
    
</div>
<section class="container my-5">
    <div class="card shadow-lg border-0 p-5">
        <div class="row align-items-center">

            <div class="col-lg-6">
                <h2 class="text-success fw-bold mb-4">Our Story</h2>

                <p class="lead">
                    Kasi Market was created with one simple goal:
                    <strong>to empower local communities by making it easier to buy and sell within South Africa.</strong>
                </p>

                <p>
                    Many talented entrepreneurs, students, and small business owners have quality
                    products and valuable skills but struggle to reach customers through traditional
                    marketplaces. Kasi Market bridges that gap by providing a secure, community-driven
                    platform where people can connect, trade, and grow together.
                </p>

                <p>
                    Whether you're selling handmade products, clothing, electronics, books, or offering
                    services, Kasi Market provides a space where local businesses can thrive while
                    customers enjoy affordable products from trusted sellers.
                </p>

                <p class="mb-0">
                    We believe that supporting local businesses strengthens communities, creates
                    opportunities, and contributes to a stronger South African economy—one transaction
                    at a time.
                </p>
            </div>

            <div class="col-lg-6 text-center">
                <img src="assets/images/logo/Kasi Market logo 1.png"
                     class="img-fluid"
                     style="max-height:350px;"
                     alt="Kasi Market">
            </div>

        </div>
    </div>
</section>
<footer class="text-center text-white py-3" style="background:#212529; margin:300px;">
    <small>
        © <?php echo date("Y"); ?> KasiMarket | All rights reserved.
    </small>
</footer>
</body>
</html>
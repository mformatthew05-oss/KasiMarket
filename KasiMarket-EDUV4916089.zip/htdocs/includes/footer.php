<hr>

<footer class="text-center text-muted py-3">
    <small>
        © <?php echo date("Y"); ?> KasiMarket. All rights reserved.
    </small>
</footer>

</body>
</html>
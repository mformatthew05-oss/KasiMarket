<!DOCTYPE html>
<html lang="en">
<head>
    
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="/assets/css/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KasiMarket</title>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">

        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="/assets/images/logo/Kasi Market logo 1.png"
                 alt="KasiMarket Logo"
                 class="logo me-2">

            <span class="brand-name">KasiMarket</span>
        </a>

    </div>
</nav>
<?php
include "config.php";
include "includes/header.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KasiMarket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .product-img {
            height: 200px;
            object-fit: contain;
            background-color: #f8f9fa;
            padding: 10px;
        }
        .product-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">KasiMarket</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="become_seller.php">Sell</a></li>
                    <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="mb-4 fw-bold text-secondary">Available Products</h2>
        
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
            <?php
$sql = "
SELECT *
FROM products
WHERE status='Available'
ORDER BY product_id DESC
";

$result = mysqli_query($conn, $sql);

        while($row = mysqli_fetch_assoc($result)){
            ?>
                <div class="col">
                    <div class="card h-100 product-card border-0 shadow-sm">
                   <img src="<?php echo $row['image']; ?>" class="card-img-top product-img" alt="<?php echo htmlspecialchars($row['title']); ?>">  
                      <div class="card-body d-flex flex-column">
                         <h5 class="card-title fw-bold text-dark text-truncate"><?php echo $row['title']; ?></h5>
                          <p class="card-text text-muted small flex-grow-1">
                             <?php echo $row['description']; ?>
                         </p>
                         <div class="mt-3">
                           <span class="fs-5 fw-bold text-success d-block mb-2">R <?php echo number_format($row['price'], 2); ?></span>
                            <a href="checkout.php?product_id=<?php echo $row['product_id']; ?>" class="btn btn-primary w-100 fw-semibold shadow-sm">
                           Buy Now
                      </a>
                 </div>
                    </div>
                 </div>
             </div>
            <?php } ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<footer class="text-center text-white py-3" style="background:#212529; margin:300px;">
    <small>
        © <?php echo date("Y"); ?> KasiMarket | All rights reserved.
    </small>
</footer>
</body>
</html>
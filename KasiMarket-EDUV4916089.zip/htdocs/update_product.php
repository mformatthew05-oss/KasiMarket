<?php
include "config.php";

$id = $_POST['id'];
$title = $_POST['title'];
$description = $_POST['description'];
$price = $_POST['price'];

$sql = "SELECT image FROM products WHERE product_id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$currentImage = $row['image'];

if (!empty($_FILES['image']['name'])) {

    $imageName = time() . "_" . $_FILES['image']['name'];
    $imageTmp = $_FILES['image']['tmp_name'];

    $uploadPath = "uploads/" . $imageName;

    move_uploaded_file($imageTmp, $uploadPath);

    $imageToSave = $uploadPath;

} else {
    $imageToSave = $currentImage;
}

$sql = "UPDATE products SET 
        title='$title',
        description='$description',
        price='$price',
        image='$imageToSave'
        WHERE product_id=$id";

if (mysqli_query($conn, $sql)) {
    header("Location: seller_product.php?updated=1");
    exit();
} else {
    echo "Error updating product";
}
?>

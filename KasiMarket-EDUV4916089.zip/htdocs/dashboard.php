<?php
session_start();
include "config.php";
include "includes/header.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'] ?? 'buyer';
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

</head>


<body
    style="
        background: url('/assets/images/logo/background.png') center center / cover no-repeat fixed;
        margin:0;
        padding:0;
    ">
<nav class="navbar navbar-dark bg-dark px-4">
    <span class="navbar-brand">KasiMarket</span>

    <div class="text-white">
        Welcome, <?php echo $username; ?>
    </div>

    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</nav>

<div class="container mt-5">

    <h2 class="mb-4">Dashboard</h2>

    <div class="row g-4  justify-content-center">

    
        <?php if ($role == "admin") { ?>

        <div class="col-md-4">
            <div class="card shadow-sm p-3">
                <h4>Admin Panel</h4>
                <p>Manage users and system</p>

                <a href="manage_users.php" class="btn btn-primary btn-sm mb-2">
                    Manage Users
                </a>

                <a href="admin_seller_request.php" class="btn btn-warning btn-sm mb-2">
                    Seller Applications
                </a>

                <a href="marketplace.php" class="btn btn-dark btn-sm">
                    View Marketplace
                </a>
            </div>
        </div>

        <?php } ?>

        <?php if ($role == "seller") { ?>

        <div class="col-md-4">
            <div class="card shadow-sm p-3">
                <h4>Seller Tools</h4>
                <p>Manage your products</p>

                <a href="seller_product.php" class="btn btn-success btn-sm mb-2">
                    My Products
                </a>

                <a href="add_product.php" class="btn btn-primary btn-sm mb-2">
                    Add Product
                </a>

                <a href="marketplace.php" class="btn btn-dark btn-sm">
                    View Marketplace
                </a>
            </div>
        </div>

        <?php } ?>

        <?php if ($role == "buyer") { ?>

        <div class="col-md-4">
            <div class="card shadow-sm">
                <h4>Buyer Area</h4>
                <p>Browse and shop products</p>

                <a href="marketplace.php" class="btn btn-primary btn-sm">
                    Browse Products
                </a>
                <br></br>
                <a href="become_seller.php" class="btn btn-primary btn-sm">
                    Sell
                </a>
            </div>
        </div>

        <?php } ?>

    </div>

</div>
<footer class="text-center text-white py-3" style="background:#212529; margin:300px;">
    <small>
        © <?php echo date("Y"); ?> KasiMarket | All rights reserved.
    </small>
</footer>
</body>
</html>
<?php
session_start();
include "config.php";
include "includes/header.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt1 = $conn->prepare("SELECT * FROM products WHERE user_id = ? AND status = 'Available'");
$stmt1->bind_param("i", $user_id);
$stmt1->execute();
$result = $stmt1->get_result();
 

$sales_sql = "
SELECT
    p.title,
    IFNULL(u.username, 'Guest Buyer') AS buyer_name,
    o.full_name,
    o.phone,
    o.address,
    o.city,
    o.province,
    o.postal_code,
    oi.quantity,
    oi.price,
    o.status AS order_status,
    o.created_at
FROM order_items oi
JOIN orders o ON oi.order_id = o.order_id
JOIN products p ON oi.product_id = p.product_id
LEFT JOIN users u ON o.user_id = u.user_id
WHERE p.user_id = ?
ORDER BY o.created_at DESC
";

$stmt2 = $conn->prepare($sales_sql);
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$sales_result = $stmt2->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>My Products</h2>
    <div>
        <a href="add_product.php" class="btn btn-success">Add Product</a>
        <a href="dashboard.php" class="btn btn-primary">Dashboard</a>
        <a href="marketplace.php" class="btn btn-outline-secondary">Back to Shop</a>
    </div>
</div>

<?php if (isset($_GET['deleted'])) { ?>
    <div class="alert alert-success">Product deleted successfully!</div>
<?php } ?>

<?php if (isset($_GET['updated'])) { ?>
    <div class="alert alert-success">Product updated successfully!</div>
<?php } ?>

<?php if (isset($_GET['success'])) { ?>
    <div class="alert alert-success">Product added successfully!</div>
<?php } ?>


<table class="table table-bordered table-hover">
    <thead class="table-dark">
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($product = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo htmlspecialchars($product['title']); ?></td>
            <td><?php echo htmlspecialchars($product['description']); ?></td>
            <td>R <?php echo number_format($product['price'], 2); ?></td>
            <td>
                <img src="<?php echo htmlspecialchars($product['image']); ?>" width="80" alt="Product Image">
            </td>
            <td>
                <a href="edit_product.php?id=<?php echo $product['product_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="delete_product.php?id=<?php echo $product['product_id']; ?>" 
                   onclick="return confirm('Are you sure you want to delete this product?');" 
                   class="btn btn-danger btn-sm">Delete</a>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>

<h3 class="mt-5">Recent Sales</h3>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Product</th>
            <th>Buyer Username</th>
            <th>Full Name</th>
            <th>Phone</th>
            <th>Delivery Address</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
    <?php while($sale = mysqli_fetch_assoc($sales_result)) { ?>
        <tr>
            <td><?php echo htmlspecialchars($sale['title']); ?></td>
            <td><?php echo htmlspecialchars($sale['buyer_name']); ?></td>
            <td><?php echo htmlspecialchars($sale['full_name']); ?></td>
            <td><?php echo htmlspecialchars($sale['phone']); ?></td>
            <td>
                <?php
                echo htmlspecialchars($sale['address']) . "<br>";
                echo htmlspecialchars($sale['city']) . ", ";
                echo htmlspecialchars($sale['province']) . "<br>";
                echo htmlspecialchars($sale['postal_code']);
                ?>
            </td>
            <td><?php echo htmlspecialchars($sale['quantity']); ?></td>
            <td>R <?php echo number_format($sale['price'], 2); ?></td>
            <td><?php echo htmlspecialchars($sale['order_status']); ?></td>
            <td><?php echo htmlspecialchars($sale['created_at']); ?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
<footer class="text-center text-white py-3" style="background:#212529; margin:300px;">
    <small>
        © <?php echo date("Y"); ?> KasiMarket | All rights reserved.
    </small>
</footer>
</body>
</html>
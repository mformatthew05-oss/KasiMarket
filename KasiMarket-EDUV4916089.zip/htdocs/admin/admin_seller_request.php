<?php
include "auth.php";
include __DIR__ . "/../config.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit();
}

$sql = "
SELECT 
    sr.id,
    sr.user_id,
    sr.status,
    sr.created_at,
    u.username,
    u.full_name
FROM seller_requests sr
JOIN users u ON sr.user_id = u.user_id
WHERE sr.status = 'pending'
";

$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            top: 0;
            left: 0;
            background: #212529;
            padding: 20px;
            z-index: 10;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
            margin-bottom: 5px;
            border-radius: 4px;
        }

        .sidebar a:hover {
            background: #343a40;
        }

        .main {
            margin-left: 240px;
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="text-center mb-3">
        <img src="/assets/images/logo/Kasi Market logo 1.png"
             alt="Kasi Market Logo"
             style="height:90px; width:auto;">
    </div>

    <h4 class="text-white text-center">Admin Panel</h4>
    <hr style="color:white;">

    <a href="/admin/dashboard.php">Dashboard</a>
    <a href="/admin/manage_users.php">Manage Users</a>
    <a href="/admin/manage_products.php">Manage Products</a>
    <a href="/marketplace.php">View Store</a>
    <a href="/admin/logout.php">Logout</a>
</div>

<div class="main">
    <div class="container-fluid mt-4">
        <h2>Pending Seller Applications</h2>

        <table class="table table-bordered table-hover mt-3">
            <thead class="table-dark">
                <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if(mysqli_num_rows($result) > 0) { ?>
                <?php while($row = mysqli_fetch_assoc($result)){ ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['full_name'] ?? 'N/A'); ?></td>
                    <td>
                        <a href="/admin/approve_seller.php?id=<?php echo urlencode($row['id']); ?>"
                           class="btn btn-success btn-sm">
                            Approve
                        </a>
                    </td>
                </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="4" class="text-center">No pending requests</td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
</html>
<?php
session_start();
include("../includes/header.php");
if (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="row justify-content-center">
        <div class="col-md-4">

            <div class="card p-4">

                <h3 class="text-center mb-3">Admin Login</h3>

                <form action="/admin/admin_login_process.php" method="POST">

                    <input type="text" name="username" class="form-control mb-3" placeholder="Username" required>

                    <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

                    <button type="submit" class="btn btn-dark w-100">Login</button>

                </form>

            </div>

        </div>
    </div>

</div>

</body>
</html>
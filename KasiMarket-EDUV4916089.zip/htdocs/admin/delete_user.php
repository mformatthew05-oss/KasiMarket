<?php
include "auth.php";
include __DIR__ . "/../config.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != "admin"){
    header("Location: ../dashboard.php");
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {

    $sql = "DELETE FROM users WHERE user_id='$id'";

    if(mysqli_query($conn, $sql)){
        header("Location: manage_users.php?deleted=1");
        exit();
    } else {
        echo "Error deleting user: " . mysqli_error($conn);
    }

} else {
    echo "Invalid user ID";
}
?>
<?php
include "auth.php";
include __DIR__ . "/../config.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit();
}
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    die("Invalid user ID");
}

$sql1 = "UPDATE users 
         SET role='seller' 
         WHERE user_id='$user_id'";

$sql2 = "UPDATE seller_requests 
         SET status='approved' 
         WHERE user_id='$user_id'";

if (mysqli_query($conn, $sql1) && mysqli_query($conn, $sql2)) {

    header("Location: admin_seller_request.php?approved=1");
    exit();

} else {
    echo "Error updating records: " . mysqli_error($conn);
}
?>
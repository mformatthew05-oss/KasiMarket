<?php
include "auth.php";
include __DIR__ . "/../config.php";

header("Location: dashboard.php");
exit();
?>
<?php
include "auth.php";
include __DIR__ . "/../config.php";


$sql = "
SELECT 
    p.product_id,
    p.title,
    p.description,
    p.price,
    p.status,
    p.image,
    u.username AS seller_name
FROM products p
JOIN users u ON p.user_id = u.user_id
ORDER BY p.product_id DESC
";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Products</title>
<link rel="stylesheet" href="/assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .card {
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        img {
            border-radius: 8px;
        } .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            background: #212529;
            padding: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
            margin-bottom: 5px;
        }

        .sidebar a:hover {
            background: #343a40;
        }

        .main {
            margin-left: 240px;
            padding: 20px;
        }
    </style>
</head>

<body>

<div class="sidebar">

    <div class="text-center mb-3">
        <img src="/assets/images/logo/Kasi Market logo 1.png"
             alt="Logo"
             style="height:90px; width:auto;">
    </div>

    <h4 class="text-white text-center">Admin Panel</h4>
    <hr style="color:white;">

    <a href="/admin/dashboard.php">Dashboard</a>
    <a href="/admin/manage_users.php">Manage Users</a>
    <a href="/admin/admin_seller_request.php">Seller Requests</a>
    <a href="/marketplace.php">View Store</a>
    <a href="/admin/logout.php">Logout</a>

</div>

<div class="main">

    <h3 class="mb-3">Manage Products</h3>

    <table class="table table-striped table-hover">

        <thead class="table-dark">
            <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Seller</th>
                <th>Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>

        <tr>

            <td>
                <img src="/<?php echo htmlspecialchars($row['image']); ?>"
                     width="60"
                     height="60"
                     style="object-fit:cover; border-radius:8px;">
            </td>

            <td><?php echo $row['title']; ?></td>

            <td><?php echo $row['seller_name']; ?></td>

            <td>R <?php echo number_format($row['price'], 2); ?></td>

            <td>
                <span class="badge bg-secondary">
                    <?php echo $row['status']; ?>
                </span>
            </td>

            <td>
                <a href="/admin/delete_product.php?id=<?php echo $row['product_id']; ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Are you sure you want to delete this product?');">
                    Delete
                </a>
            </td>
        </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

</body>
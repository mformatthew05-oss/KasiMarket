<?php
include "auth.php";
include __DIR__ . "/../config.php";

$id = $_GET['id'];


mysqli_query($conn, "DELETE FROM order_items WHERE product_id='$id'");


mysqli_query($conn, "DELETE FROM products WHERE product_id='$id'");



if ($_SESSION['role'] === 'admin') {
    header("Location: /admin/manage_products.php?deleted=1");
    exit();
}

if ($_SESSION['role'] === 'seller') {
    header("Location: /seller/seller_product.php?deleted=1");
    exit();
}


header("Location: /index.php");
exit();
?>
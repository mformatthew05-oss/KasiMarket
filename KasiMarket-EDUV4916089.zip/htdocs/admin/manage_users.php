<?php
include "auth.php";
include __DIR__ . "/../config.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="/assets/css/style.css">

    <style>
        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            background: #212529;
            padding: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
            margin-bottom: 5px;
        }

        .sidebar a:hover {
            background: #343a40;
        }

        .main {
            margin-left: 240px;
            padding: 20px;
        }
    </style>
</head>

<body>


<div class="sidebar">
<div class="text-center mb-3">
    <img src="/assets/images/logo/Kasi Market logo 1.png"
         alt="Logo"
         style="height: 90px; width: auto;">
</div>

<h4 class="text-white text-center">Admin Panel</h4>
    <hr style="color:white;">

    <a href="/admin/dashboard.php">Dashboard</a>
    <a href="/admin/admin_seller_request.php">Seller Requests</a>
    <a href="/marketplace.php">View Store</a>
    <a href="/admin/manage_products.php">Manage Products</a>
    <a href="/logout.php">Logout</a>
</div>


<div class="main">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Admin - Manage Users</h2>

        <a href="/admin/create_user.php"
           class="btn btn-success">
            Create New User
        </a>
    </div>

    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Action</th>
        </tr>

        <?php
        $sql = "SELECT * FROM users";
        $result = mysqli_query($conn, $sql);

        while ($row = mysqli_fetch_assoc($result)) {
        ?>

        <tr>
            <td><?php echo $row['user_id']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['role']; ?></td>
            <td>
                <a href="/admin/edit_user.php?id=<?php echo $row['user_id']; ?>"
                   class="btn btn-warning btn-sm">
                    Edit User
                </a>

                <a href="/admin/delete_user.php?id=<?php echo $row['user_id']; ?>"
                   onclick="return confirm('Are you sure you want to delete this user?');"
                   class="btn btn-danger btn-sm">
                    Delete
                </a>
            </td>
        </tr>

        <?php } ?>
    </table>

</div>

</body>
</html>
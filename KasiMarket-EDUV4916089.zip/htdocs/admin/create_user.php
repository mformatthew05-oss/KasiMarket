<?php
include "auth.php";
include __DIR__ . "/../config.php";
include("../includes/header.php");

if ($_SESSION['role'] !== 'admin') {
    header("Location: dashboard.php");
    exit();
}

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {

        $check = "SELECT * FROM users WHERE username='$username' OR email='$email'";
        $result = mysqli_query($conn, $check);

        if (mysqli_num_rows($result) > 0) {
            $error = "Username or email already exists.";
        } else {

            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            
            $sql = "INSERT INTO users (username, email, password, role)
                    VALUES ('$username', '$email', '$hashed_password', '$role')";

            if (mysqli_query($conn, $sql)) {
                $message = "User created successfully!";
            } else {
                $error = "Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create User</title>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
        }

        .card {
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
    </style>
</head>

<body>

<div class="container mt-5">

    <div class="row justify-content-center">

        <div class="col-md-6">

            <div class="card p-4">

                <h3 class="text-center mb-3">Create New User</h3>

                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST">

                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control mb-3" required>

                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control mb-3" required>

                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control mb-3" required>

                    <label class="form-label">Role</label>
                    <select name="role" class="form-select mb-3" required>
                        <option value="buyer">Buyer</option>
                        <option value="seller">Seller</option>
                        <option value="admin">Admin</option>
                    </select>

                    <button type="submit" class="btn btn-success w-100">
                        Create User
                    </button>

                    <a href="manage_users.php" class="btn btn-secondary w-100 mt-2">
                        Back to Users
                    </a>

                </form>

            </div>

        </div>

    </div>

</div>

</body>
</html>
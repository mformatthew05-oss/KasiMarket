<?php
include "auth.php";
include __DIR__ . "/../config.php";

$user_id = $_POST['user_id'];
$role = $_POST['role'];

$sql = "UPDATE users SET role='$role' WHERE user_id='$user_id'";

if(mysqli_query($conn, $sql)){
    header("Location: manage_users.php");
    exit();
} else {
    echo "Error updating user";
}
?>
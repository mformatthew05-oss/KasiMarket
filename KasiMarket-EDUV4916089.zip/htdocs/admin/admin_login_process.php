<?php
session_start();
include __DIR__ . "/../config.php";

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$sql = "SELECT * FROM users WHERE username='$username' LIMIT 1";
$result = mysqli_query($conn, $sql);

$user = mysqli_fetch_assoc($result);

if ($user) {


    if (password_verify($password, $user['password'])) {

        if ($user['role'] === 'admin') {

            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

			header("Location: /admin/dashboard.php");
			exit();

        } else {
            echo "Access denied. Admins only.";
        }

    } else {
        echo "Wrong password.";
    }

} else {
    echo "User not found.";
}
?>
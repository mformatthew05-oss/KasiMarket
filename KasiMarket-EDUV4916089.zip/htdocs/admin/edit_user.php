<?php
include "auth.php";
include __DIR__ . "/../config.php";
include("../includes/header.php");

$id = $_GET['id'];

$sql = "SELECT * FROM users WHERE user_id='$id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User Role</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="/assets/css/style.css">
    <style>

        .card {
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .badge-role {
            font-size: 0.85rem;
            padding: 6px 10px;
        }

        .container {
            margin-top: 60px;
        }
    </style>
</head>

<body>

<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-6">

            <div class="card p-4">

                <h3 class="mb-3 text-center">Edit User Role</h3>

                <p class="text-muted text-center mb-4">
                    Update the role for this user in the system
                </p>

            
                <div class="mb-3">
                    <label class="form-label fw-bold">Username</label>
                    <div class="form-control bg-light">
                        <?php echo $user['username']; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Email</label>
                    <div class="form-control bg-light">
                        <?php echo $user['email']; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Current Role</label>
                    <div>
                        <span class="badge bg-primary badge-role">
                            <?php echo $user['role']; ?>
                        </span>
                    </div>
                </div>
                <form method="POST" action="update_user.php">

                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">

                    <label class="form-label fw-bold">Change Role</label>

                    <select name="role" class="form-select mb-3" required>
                        <option value="buyer" <?php if($user['role']=="buyer") echo "selected"; ?>>
                            Buyer
                        </option>

                        <option value="seller" <?php if($user['role']=="seller") echo "selected"; ?>>
                            Seller
                        </option>

                        <option value="admin" <?php if($user['role']=="admin") echo "selected"; ?>>
                            Admin
                        </option>
                    </select>

                    <button type="submit" class="btn btn-success w-100">
                        Update Role
                    </button>

                    <a href="manage_users.php" class="btn btn-secondary w-100 mt-2">
                        Back to Users
                    </a>

                </form>

            </div>

        </div>

    </div>
</div>

</body>
</html>
<?php
include "auth.php";
include __DIR__ . "/../config.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="/assets/css/style.css">

    <style>
   {
            margin: 0;
        }

        .sidebar {
            height: 100vh;
            background: rgba(33, 37, 41, 0.95);
            padding: 20px;
            position: fixed;
            width: 220px;
        }

        .sidebar a {
            color: white;
            display: block;
            padding: 10px;
            text-decoration: none;
            margin-bottom: 5px;
            border-radius: 5px;
        }

        .sidebar a:hover {
            background: #343a40;
        }

        .main {
            margin-left: 240px;
            padding: 20px;
        }

        .card-box {
            padding: 20px;
            border-radius: 10px;
            color: white;
        }

        .blue { background: #0d6efd; }
        .green { background: #198754; }
        .orange { background: #fd7e14; }
        .red { background: #dc3545; }
    </style>
</head>

<body>


<div class="sidebar">


    <div class="text-center mb-3">
        <img src="/assets/images/logo/Kasi Market logo 1.png"
             style="height:80px; width:auto;">
    </div>

    <h5 class="text-white text-center">Admin Panel</h5>
    <hr style="color:white;">

    <a href="/admin/manage_users.php">Manage Users</a>
    <a href="/admin/admin_seller_request.php">Seller Requests</a>
    <a href="/admin/manage_products.php">Manage Products</a>
    <a href="/marketplace.php">View Store</a>
    <a href="/admin/logout.php">Logout</a>
</div>


<div class="main">

    <h2>System Overview</h2>

    <div class="row">

        <div class="col-md-3">
            <div class="card-box blue">
                <h5>Total Users</h5>
                <?php
                $q = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
                $d = mysqli_fetch_assoc($q);
                echo "<h3>".$d['total']."</h3>";
                ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box green">
                <h5>Total Sellers</h5>
                <?php
                $q = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='seller'");
                $d = mysqli_fetch_assoc($q);
                echo "<h3>".$d['total']."</h3>";
                ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box orange">
                <h5>Total Products</h5>
                <?php
                $q = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products");
                $d = mysqli_fetch_assoc($q);
                echo "<h3>".$d['total']."</h3>";
                ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box red">
                <h5>Total Orders</h5>
                <?php
                $q = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders");
                $d = mysqli_fetch_assoc($q);
                echo "<h3>".$d['total']."</h3>";
                ?>
            </div>
        </div>

    </div>

</div>

</body>
</html>
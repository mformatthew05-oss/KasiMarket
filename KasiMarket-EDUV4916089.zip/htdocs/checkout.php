<?php
session_start();
include "config.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$product_id = $_GET['product_id'];

$sql = "SELECT * FROM products WHERE product_id='$product_id'";
$result = mysqli_query($conn, $sql);
$product = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/C2C_PLATFORM_EDUV4916089/assets/css/style.css">
</head>
<body>
<?php include("includes/header.php"); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="card p-4 mx-auto" style="max-width: 800px;">

    <h2 class="mb-4">Checkout Page</h2>

    <form action="process_payment.php" method="POST" onsubmit="return validateCheckout()">

        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">

        <h4>Delivery Information</h4>

        <input type="text" name="full_name"
               class="form-control mb-3"
               placeholder="Full Name" required>

        <input type="tel" name="phone"
               class="form-control mb-3"
               placeholder="Phone Number" required>

        <textarea name="address"
                  class="form-control mb-3"
                  placeholder="Street Address" required></textarea>

        <input type="text" name="city"
               class="form-control mb-3"
               placeholder="City" required>

        <input type="text" name="province"
               class="form-control mb-3"
               placeholder="Province" required>

        <input type="text" name="postal_code"
               class="form-control mb-3"
               placeholder="Postal Code" required>

        <hr>

        <h4>Payment Information</h4>

        <input type="text" name="card_name"
               class="form-control mb-3"
               placeholder="Card Name" required>

        <input type="text" name="card_number"
               class="form-control mb-3"
               placeholder="Card Number" required>

        <input type="text" name="expiry"
               class="form-control mb-3"
               placeholder="MM/YY" required>

        <input type="text" name="cvv"
               class="form-control mb-3"
               placeholder="CVV" required>

        <button type="submit" class="btn btn-success w-100">
            Pay Now
        </button>

    </form>

</div>
<script>
function validateCheckout() {

    let cardNumber = document.querySelector('[name="card_number"]').value;
    let cvv = document.querySelector('[name="cvv"]').value;
    let phone = document.querySelector('[name="phone"]').value;
    let expiry = document.querySelector('[name="expiry"]').value;

    if (!/^\d{10}$/.test(phone)) {
        alert("Phone number must be 10 digits.");
        return false;
    }

    if (!/^\d{16}$/.test(cardNumber)) {
        alert("Card number must be 16 digits.");
        return false;
    }

    if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry)) {
        alert("Expiry date must be in MM/YY format.");
        return false;
    }

    let [month, year] = expiry.split("/").map(Number);

    let currentYear = new Date().getFullYear() % 100;
    let currentMonth = new Date().getMonth() + 1;

    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        alert("Card expiry month is in the past.");
        return false;
    }

    if (!/^\d{3}$/.test(cvv)) {
        alert("CVV must be 3 digits.");
        return false;
    }

    return true;
}
</script>
<footer class="text-center text-white py-3" style="background:#212529; margin:300px;">
    <small>
        © <?php echo date("Y"); ?> KasiMarket | All rights reserved.
    </small>
</footer>
</body>
</html>

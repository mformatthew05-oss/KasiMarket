<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$buyer_id = $_SESSION['user_id'];

$product_id = $_POST['product_id'];

$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'];
$province = $_POST['province'];
$postal_code = $_POST['postal_code'];

$card_name = $_POST['card_name'];
$card_number = $_POST['card_number'];
$expiry = $_POST['expiry'];
$cvv = $_POST['cvv'];


$product_sql = "SELECT * FROM products WHERE product_id='$product_id'";
$product_result = mysqli_query($conn, $product_sql);

if (!$product_result || mysqli_num_rows($product_result) == 0) {
    die("Product not found.");
}

$product = mysqli_fetch_assoc($product_result);

$seller_id = $product['user_id'];
$total = $product['price'];


$payment_status = "Successful";


$payment_sql = "
INSERT INTO payments
(
    payment_method,
    card_number,
    card_holder,
    expiry_date,
    amount,
    payment_status
)
VALUES
(
    'Card',
    '$card_number',
    '$card_name',
    '$expiry',
    '$total',
    '$payment_status'
)";

mysqli_query($conn, $payment_sql);

$order_sql = "
INSERT INTO orders
(
    user_id,
    total,
    status,
    created_at,
    full_name,
    phone,
    address,
    city,
    province,
    postal_code
)
VALUES
(
    '$buyer_id',
    '$total',
    'Paid',
    NOW(),
    '$full_name',
    '$phone',
    '$address',
    '$city',
    '$province',
    '$postal_code'
)";

if (!mysqli_query($conn, $order_sql)) {
    die("Error creating order: " . mysqli_error($conn));
}

$order_id = mysqli_insert_id($conn);


$order_item_sql = "
INSERT INTO order_items
(
    order_id,
    product_id,
    quantity,
    price
)
VALUES
(
    '$order_id',
    '$product_id',
    1,
    '$total'
)";

if (!mysqli_query($conn, $order_item_sql)) {
    die("Error creating order item: " . mysqli_error($conn));
}

$sold_sql = "
UPDATE products
SET status='Sold'
WHERE product_id='$product_id'
";

mysqli_query($conn, $sold_sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Successful</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-5">

    <div class="alert alert-success">
        <h2>Payment Successful!</h2>
        <p>Your order has been placed successfully.</p>
    </div>

    <div class="card p-4">

        <h4>Order Summary</h4>

        <p>
            <strong>Product:</strong>
            <?php echo htmlspecialchars($product['title']); ?>
        </p>

        <p>
            <strong>Amount Paid:</strong>
            R <?php echo number_format($total, 2); ?>
        </p>

        <p>
            <strong>Order ID:</strong>
            <?php echo $order_id; ?>
        </p>

        <a href="marketplace.php" class="btn btn-primary">
            Back to Marketplace
        </a>

    </div>

</body>
</html>
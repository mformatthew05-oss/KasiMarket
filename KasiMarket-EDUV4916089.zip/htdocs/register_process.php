<?php
include "config.php";

if(isset($_POST['username'], $_POST['email'], $_POST['password'], $_POST['full_name'])){

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $name = $_POST['full_name'];
    $role = "buyer";


    $check = "SELECT * FROM users WHERE username='$username' OR email='$email'";
    $result = mysqli_query($conn, $check);

    if(mysqli_num_rows($result) > 0){
        echo "Username or Email already exists!";
        exit();
    }


    $sql = "INSERT INTO users (username, email, full_name, password, role)
            VALUES ('$username', '$email', '$name', '$password', '$role')";

    if(mysqli_query($conn, $sql)){

        header("Location: login.php?registered=1");
        exit();

    } else {
        echo "Error: " . mysqli_error($conn);
    }

} else {
    echo "Please fill in all fields!";
}
?>
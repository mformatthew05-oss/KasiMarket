<?php
session_start();
include "includes/header.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-5">

    <div class="card p-4 mx-auto shadow" style="max-width: 400px;">

        <?php
        if (isset($_GET['registered'])) {
            echo "<div class='alert alert-success text-center'>
                    Registration successful! Please log in.
                  </div>";
        }
        if (isset($_SESSION['login_error'])) {
            echo "<div class='alert alert-danger text-center'>
                    " . htmlspecialchars($_SESSION['login_error']) . "
                  </div>";

            unset($_SESSION['login_error']);
        }
        ?>

        <h2 class="text-center mb-4">Login</h2>

        <form action="login_process.php" method="POST">

            <input
                type="email"
                name="email"
                class="form-control mb-3"
                placeholder="Email"
                value="<?php
                    if (isset($_SESSION['old_email'])) {
                        echo htmlspecialchars($_SESSION['old_email']);
                        unset($_SESSION['old_email']);
                    }
                ?>"
                required
            >

            <input
                type="password"
                name="password"
                class="form-control mb-3"
                placeholder="Password"
                required
            >

            <button type="submit" class="btn btn-primary w-100">
                Login
            </button>

        </form>

        <p class="text-center mt-3 mb-0">
            Don't have an account?
            <a href="register.php">Register Here</a>
        </p>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>